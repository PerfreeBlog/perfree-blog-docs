const s="/assets/1732155174095.idtrM8cr.jpg";export{s as _};
